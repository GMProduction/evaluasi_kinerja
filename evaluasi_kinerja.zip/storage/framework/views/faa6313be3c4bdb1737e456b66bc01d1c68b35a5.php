

<?php $__env->startSection('moreCss'); ?>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <section class="mt-content">
        <?php if(auth()->user()->roles[0] == 'superuser' || auth()->user()->roles[0] == 'admin'): ?>
            <?php echo $__env->make('superuser.dashboard.superuser', ['data' => 'content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('superuser.dashboard.table', ['data' => 'content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif(auth()->user()->roles[0] == 'accessor' || auth()->user()->roles[0] == 'accessorppk'): ?>

            <?php echo $__env->make('superuser.dashboard.accessor',['data' => 'content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('superuser.dashboard.vendor',['data' => 'content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php if(auth()->user()->roles[0] == 'superuser' || auth()->user()->roles[0] == 'admin'): ?>
        <?php echo $__env->make('superuser.dashboard.superuser', ['data' => 'script'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('superuser.dashboard.table', ['data' => 'script'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(auth()->user()->roles[0] == 'accessor' || auth()->user()->roles[0] == 'accessorppk'): ?>
        <?php echo $__env->make('superuser.dashboard.accessor',['data' => 'script'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('superuser.dashboard.vendor',['data' => 'script'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <script>
        var roles, textRoles;
        var table;
        $(document).ready(function() {
            // chart()
            // cahar11()
            roles = 'superuser';
            textRoles = 'Superuser'
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superuser.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT\WEBSITE\cilikan\evaluasi_kinerja\resources\views/superuser/dashboard.blade.php ENDPATH**/ ?>