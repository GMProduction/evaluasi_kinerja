

<?php $__env->startSection('moreCss'); ?>
    
    <style>
        .card-vendor-2 {
            padding: 16px;
            -webkit-box-shadow: rgba(50, 50, 93, 0.01) 0px 2px 5px -1px, rgba(0, 0, 0, 0.1) 0px 1px 3px -1px;
            box-shadow: rgba(50, 50, 93, 0.01) 0px 2px 5px -1px, rgba(0, 0, 0, 0.1) 0px 1px 3px -1px;
            background-color: white;
            border-radius: 10px;
            height: 150px;
            cursor: pointer;
            -webkit-transition: all 300ms;
            transition: all 300ms;
        }

        .card-vendor-2:hover {
            box-shadow: #1F9CAC55 0px 7px 29px 0px;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <section class="mt-content">
        <?php if(auth()->user()->roles[0] == 'superuser' || auth()->user()->roles[0] == 'admin'): ?>
            <?php echo $__env->make('superuser.dashboard.superuser', ['data' => 'content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('superuser.dashboard.table', ['data' => 'content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif(auth()->user()->roles[0] == 'accessor' || auth()->user()->roles[0] == 'accessorppk'): ?>

            <?php echo $__env->make('superuser.dashboard.accessor',['data' => 'content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('superuser.dashboard.vendor',['data' => 'content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php if(auth()->user()->roles[0] == 'superuser' || auth()->user()->roles[0] == 'admin'): ?>
        <?php echo $__env->make('superuser.dashboard.superuser', ['data' => 'script'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('superuser.dashboard.table', ['data' => 'script'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(auth()->user()->roles[0] == 'accessor' || auth()->user()->roles[0] == 'accessorppk'): ?>
        <?php echo $__env->make('superuser.dashboard.accessor',['data' => 'script'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('superuser.dashboard.vendor',['data' => 'script'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <script>
        var roles, textRoles;
        var table;
        $(document).ready(function() {
            // chart()
            // cahar11()
            roles = 'superuser';
            textRoles = 'Superuser'
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superuser.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT\WEBSITE\cilikan\evaluasi_kinerja\resources\views/superuser/dashboard.blade.php ENDPATH**/ ?>