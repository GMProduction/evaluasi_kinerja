

<?php $__env->startSection('content'); ?>
    <style>
        .paket td {
            font-size: unset;
        }

    </style>
    <section class="pt-3">
        <div class="row justify-content-center mt-3">
            <?php if($type == 'vendor'): ?>
                <?php
                    $text = '';
                    switch ($data->notification->score->score) {
                        case 1:
                            $text = 'Buruk';
                            break;
                        case 2:
                            $text = 'Cukup';
                            break;
                        case 3:
                            $text = 'Baik';
                            break;
                        default:
                            break;
                    }
                ?>


                <div class="col-8 table-container ">
                    <p class="fw-bold t-primary mb-3">Peringatan Penilaian</p>

                    <table class="paket">
                        <tr>
                            <td style="width: 100px">Paket</td>
                            <td>: &nbsp;</td>
                            <td><span class="fw-bold "
                                    style="color: gray"><?php echo e($data->notification->score->package->name); ?></span></td>
                        </tr>
                        <tr>
                            <td style="height: 40px">Indikator</td>
                            <td>: &nbsp;</td>
                            <td><span class="fw-bold "
                                    style="color: gray"><?php echo e($data->notification->score->subIndicator->indicator->name); ?></span>
                            </td>
                        </tr>
                    </table>
                    <p style="font-size: .8rem" class="mt-2">Peringatan Penilaian Terhadap Indikator <span
                            style="font-weight: bold"><?php echo e($data->notification->score->subIndicator->name); ?></span>
                        Mendapatkan Catatan
                        Penilaian Sebagai Berikut : </p>
                    <table class="table table-stiped">
                        <thead class="thead-dark ">
                            <tr>
                                <td>Nilai</td>
                                <td>Nilai Angka</td>
                                <td>Note</td>
                                <td>File Lampiran</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <?php echo e($text); ?>

                                </td>
                                <td>
                                    <?php echo e($data->notification->score->score); ?>

                                </td>
                                <td>
                                    <?php echo e($data->notification->score->note ?? '-'); ?>

                                </td>
                                <td>
                                    <?php if($data->notification->score->file == null): ?>
                                        -
                                    <?php else: ?>
                                        <a href="<?php echo e($data->notification->score->file); ?>">Unduh</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>

                <div class="col-8 table-container ">
                    <p class="fw-bold t-primary mb-3">Sanggahan Vendor</p>
                    <table class="paket mb-4">
                        <tr class="mb-1">
                            <td style="width: 150px">Nama Vendor</td>
                            <td style=" vertical-align: top">:&nbsp;</td>
                            <td style="color: gray"><?php echo e($data->sender->vendor->name); ?></td>
                        </tr>
                        <tr class="mb-1">
                            <td style="width: 150px; vertical-align: top">Catatan Sanggah</td>
                            <td style=" vertical-align: top">:&nbsp;</td>
                            <td>
                                <p class="mb-0" style="color: gray"><?php echo e($data->text ?? '-'); ?></p>
                            </td>
                        </tr>
                        <tr class="mb-1">
                            <td>File Terlampir</td>
                            <td>:&nbsp;</td>
                            <td><a class="<?php echo e($data->file ? 'bt-success-xsm' : ''); ?>" target="_blank"
                                    href="<?php echo e($data->file ?? ''); ?>"><?php echo e($data->file ? 'Download' : 'Tidak ada file'); ?>


                                </a></td>

                        </tr>
                        <tr class="mb-1">
                            <td>Tanggal Sanggah</td>
                            <td>:&nbsp;</td>
                            <td style="color: gray"><?php echo e(\Carbon\Carbon::parse($data->updated_at)->isoFormat('LLL')); ?></td>
                        </tr>
                    </table>
                    <a class="btn bt-primary mt-4"
                        href="/penilaian/detail/<?php echo e($data->notification->score->package_id); ?>?q=<?php echo e($data->notification->score->id); ?>">Lihat
                        Penilaian</a>
                </div>
            <?php else: ?>
                <?php
                    $text = '';
                    switch ($data->score->score) {
                        case 1:
                            $text = 'Buruk';
                            break;
                        case 2:
                            $text = 'Cukup';
                            break;
                        case 3:
                            $text = 'Baik';
                            break;
                        default:
                            break;
                    }
                ?>

                <div class="col-8 table-container ">
                    <p class="">Peringatan Penilaian</p>
                    <p>Peringatan Penilaian Terhadap Indikator <span
                            style="
                        font-weight: bold"><?php echo e($data->score->subIndicator->name); ?></span> Mendapatkan Catatan
                        Penilaian Sebagai Berikut : </p>
                    <table class="table">
                        <thead>
                            <tr>
                                <td>Nilai</td>
                                <td>Nilai Angka</td>
                                <td>Note</td>
                                <td>File Lampiran</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <?php echo e($text); ?>

                                </td>
                                <td>
                                    <?php echo e($data->score->score); ?>

                                </td>
                                <td>
                                    <?php echo e($data->score->note ?? '-'); ?>

                                </td>
                                <td>
                                    <?php if($data->score->file == null): ?>
                                        -
                                    <?php else: ?>
                                        <a href="<?php echo e($data->score->file); ?>">Unduh</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <form id="form" onsubmit="return save()">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($data->id); ?>" name="id">
                        <?php if($data->claim != null): ?>
                            <input type="hidden" value="<?php echo e($data->claim->id); ?>" name="claim_id">
                        <?php endif; ?>
                        <div class="mb-3">
                            <label for="text" class="form-label">Catatan Sanggah</label>
                            <textarea type="text" class="form-control" id="text"
                                name="text"><?php echo e($data->claim && $data->claim->text ? $data->claim->text : ''); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="file" class="form-label">File</label>
                            <input type="file" id="file" name="file" class="form-control">
                            <a class="<?php echo e($data->claim && $data->claim->file ? '' : 'd-none'); ?>" target="_blank"
                                href="<?php echo e($data->claim && $data->claim->file ? $data->claim->file : ''); ?>"><?php echo e($data->claim && $data->claim->file ? $data->claim->file : ''); ?></a>
                        </div>
                        <button type="submit" class="btn bt-primary">Simpan</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function save() {
            if ($('#text').val() === '' && $('#file').val() === '') {
                swal("Silahkan mengisi catatan atau melampirkan file untuk menyanggah ", {
                    icon: "warning",
                })
                return false
            }
            saveData('Sanggah', 'form', '/peringatan/claim', aftersave)
            return false;
        }

        function aftersave() {
            window.location.href = '/peringatan';
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superuser.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PROJECT\WEBSITE\cilikan\evaluasi_kinerja\resources\views/superuser/notification/notification-detail.blade.php ENDPATH**/ ?>